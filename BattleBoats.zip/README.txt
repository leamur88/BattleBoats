# BattleBoats
Written by leibo023 and osmun046

WHAT EACH PARTNER DID
Jonathan Leibovich
-missileFire method in BattleBoatsBoard
-missile method in BattleBoatsBoard
-missile implementaion in BattleBoats main
-printBoard helper in BattleBoats main
-Start of main method in BattleBoats (until //MAIN WHILE)

Ethan Osmundson
-Boats class
-UserBoard class
-fire method in BattleBoatsBoard
-drone method in BattleBoatsBoard
-drone implementation in BattleBoats main
-quit in BattleBoats main
-formatting and polishing

Together
-placeBoats method in BattleBoatsBoard
-Time complexity


ADDITIONAL FEATURES
Sarcasm and insults. Nothing else really.


HOW TO RUN
Compile all files and run BattleBoats.java. 
Dependencies are BattleBoatsBoard.java, Boats.java, and UserBoard.java.


KNOWN BUGS/DEFECTS
-If an integer input is expected and a float, string or character is given instead the program crashes
